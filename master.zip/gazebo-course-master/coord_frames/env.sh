export GAZEBO_PLUGIN_PATH=$GAZEBO_PLUGIN_PATH:/home/drum/course/gazebo-course/coord_frames/debug
export GAZEBO_MODEL_PATH=/home/drum/course/gazebo_models:$GAZEBO_MODEL_PATH:/home/drum/course/gazebo-course/coord_frames

