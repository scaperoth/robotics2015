export GAZEBO_PLUGIN_PATH=/home/scaperoth/Desktop/school/2015/robotics/gazebo-course/coord_frames/build
export GAZEBO_MODEL_PATH=/home/scaperoth/Desktop/school/2015/robotics/gazebo-course/coord_frames

